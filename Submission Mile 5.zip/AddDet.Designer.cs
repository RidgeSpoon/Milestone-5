﻿namespace Mile_Stone_Inventory_Moving_List
{
    partial class AddDet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddDet));
            this.addButt = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.cellNum = new System.Windows.Forms.NumericUpDown();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.nameBox = new System.Windows.Forms.TextBox();
            this.ethBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.charBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.addButt2 = new System.Windows.Forms.Button();
            this.addButt3 = new System.Windows.Forms.Button();
            this.addButt4 = new System.Windows.Forms.Button();
            this.addButt5 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.cellNum)).BeginInit();
            this.SuspendLayout();
            // 
            // addButt
            // 
            this.addButt.BackColor = System.Drawing.SystemColors.Highlight;
            this.addButt.Location = new System.Drawing.Point(12, 257);
            this.addButt.Name = "addButt";
            this.addButt.Size = new System.Drawing.Size(214, 23);
            this.addButt.TabIndex = 0;
            this.addButt.Text = "Submit to Room 1";
            this.addButt.UseVisualStyleBackColor = false;
            this.addButt.Click += new System.EventHandler(this.addButt_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "Assign Cell";
            // 
            // cellNum
            // 
            this.cellNum.BackColor = System.Drawing.SystemColors.HotTrack;
            this.cellNum.Location = new System.Drawing.Point(95, 18);
            this.cellNum.Name = "cellNum";
            this.cellNum.Size = new System.Drawing.Size(131, 23);
            this.cellNum.TabIndex = 2;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CalendarMonthBackground = System.Drawing.SystemColors.HotTrack;
            this.dateTimePicker1.CalendarTitleBackColor = System.Drawing.SystemColors.Highlight;
            this.dateTimePicker1.CalendarTrailingForeColor = System.Drawing.SystemColors.HotTrack;
            this.dateTimePicker1.Location = new System.Drawing.Point(12, 70);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(214, 23);
            this.dateTimePicker1.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(95, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 15);
            this.label2.TabIndex = 4;
            this.label2.Text = "Birthdate";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 122);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 15);
            this.label3.TabIndex = 5;
            this.label3.Text = "Name";
            // 
            // nameBox
            // 
            this.nameBox.BackColor = System.Drawing.SystemColors.HotTrack;
            this.nameBox.ForeColor = System.Drawing.SystemColors.WindowText;
            this.nameBox.Location = new System.Drawing.Point(57, 119);
            this.nameBox.Name = "nameBox";
            this.nameBox.Size = new System.Drawing.Size(169, 23);
            this.nameBox.TabIndex = 6;
            // 
            // ethBox
            // 
            this.ethBox.BackColor = System.Drawing.SystemColors.HotTrack;
            this.ethBox.Location = new System.Drawing.Point(71, 162);
            this.ethBox.Name = "ethBox";
            this.ethBox.Size = new System.Drawing.Size(155, 23);
            this.ethBox.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 165);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 15);
            this.label4.TabIndex = 7;
            this.label4.Text = "Ethnicity";
            // 
            // charBox
            // 
            this.charBox.BackColor = System.Drawing.SystemColors.HotTrack;
            this.charBox.Location = new System.Drawing.Point(68, 212);
            this.charBox.Name = "charBox";
            this.charBox.Size = new System.Drawing.Size(158, 23);
            this.charBox.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 215);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 15);
            this.label5.TabIndex = 9;
            this.label5.Text = "Charges";
            // 
            // addButt2
            // 
            this.addButt2.BackColor = System.Drawing.SystemColors.Highlight;
            this.addButt2.Location = new System.Drawing.Point(12, 286);
            this.addButt2.Name = "addButt2";
            this.addButt2.Size = new System.Drawing.Size(214, 23);
            this.addButt2.TabIndex = 11;
            this.addButt2.Text = "Submit to Room 2";
            this.addButt2.UseVisualStyleBackColor = false;
            this.addButt2.Click += new System.EventHandler(this.addButt2_Click);
            // 
            // addButt3
            // 
            this.addButt3.BackColor = System.Drawing.SystemColors.Highlight;
            this.addButt3.Location = new System.Drawing.Point(12, 315);
            this.addButt3.Name = "addButt3";
            this.addButt3.Size = new System.Drawing.Size(214, 23);
            this.addButt3.TabIndex = 12;
            this.addButt3.Text = "Submit to Room 3";
            this.addButt3.UseVisualStyleBackColor = false;
            this.addButt3.Click += new System.EventHandler(this.addButt3_Click);
            // 
            // addButt4
            // 
            this.addButt4.BackColor = System.Drawing.SystemColors.Highlight;
            this.addButt4.Location = new System.Drawing.Point(12, 344);
            this.addButt4.Name = "addButt4";
            this.addButt4.Size = new System.Drawing.Size(214, 23);
            this.addButt4.TabIndex = 13;
            this.addButt4.Text = "Submit to Room 4";
            this.addButt4.UseVisualStyleBackColor = false;
            this.addButt4.Click += new System.EventHandler(this.addButt4_Click);
            // 
            // addButt5
            // 
            this.addButt5.BackColor = System.Drawing.SystemColors.Highlight;
            this.addButt5.Location = new System.Drawing.Point(12, 373);
            this.addButt5.Name = "addButt5";
            this.addButt5.Size = new System.Drawing.Size(214, 23);
            this.addButt5.TabIndex = 14;
            this.addButt5.Text = "Submit to Room 5";
            this.addButt5.UseVisualStyleBackColor = false;
            this.addButt5.Click += new System.EventHandler(this.addButt5_Click);
            // 
            // AddDet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(238, 408);
            this.Controls.Add(this.addButt5);
            this.Controls.Add(this.addButt4);
            this.Controls.Add(this.addButt3);
            this.Controls.Add(this.addButt2);
            this.Controls.Add(this.charBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.ethBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.nameBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.cellNum);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.addButt);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AddDet";
            this.Text = "AddDet";
            ((System.ComponentModel.ISupportInitialize)(this.cellNum)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button addButt;
        private Label label1;
        private NumericUpDown cellNum;
        private DateTimePicker dateTimePicker1;
        private Label label2;
        private Label label3;
        private TextBox nameBox;
        private TextBox ethBox;
        private Label label4;
        private TextBox charBox;
        private Label label5;
        private Button addButt2;
        private Button addButt3;
        private Button addButt4;
        private Button addButt5;
    }
}